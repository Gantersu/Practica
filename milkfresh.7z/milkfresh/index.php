<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Продукция</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/header.css">
    <link rel="stylesheet" href="css/footer.css">
</head>
<body>
    <?php
        include "header_auto.html"
    ?>
    <main>
        <section id="product-categories">
            <div class="category" data-category="Молоко">
                <h3>Молоко</h3>
                <div class="product-container">
                    <!--  Товары будут добавлены сюда через JavaScript -->
                </div>
            </div>

            <div class="category" data-category="Творог">
                <h3>Творог</h3>
                <div class="product-container">
                    <!--  Товары будут добавлены сюда через JavaScript -->
                </div>
            </div>

            <div class="category" data-category="Йогурт">
                <h3>Йогурт</h3>
                <div class="product-container">
                    <!--  Товары будут добавлены сюда через JavaScript -->
                </div>
            </div>

            <div class="category" data-category="Сыр">
                <h3>Сыр</h3>
                <div class="product-container">
                    <!--  Товары будут добавлены сюда через JavaScript -->
                </div>
            </div>
        </section>

        <section id="shopping-cart">
            <h2>Оформление заказа</h2>
            <div id="cart-items">
                <!--  Товары в корзине будут добавлены сюда через JavaScript -->
            </div>

            <div id="cart-total">
                <strong>Итого: </strong> <span id="total-price">0.00</span> руб.
            </div>

            <form id="order-form">
                <label for="address">Адрес доставки:</label>
                <textarea id="address" name="address" required></textarea>

                <label for="phone">Номер телефона:</label>
                <input type="tel" id="phone" name="phone" required>

                <label for="payment">Способ оплаты:</label>
                <select id="payment" name="payment">
                    <option value="card">Банковской картой</option>
                    <option value="cash">Наличными</option>
                </select>

                <button type="submit">Оформить заказ</button>
                
            </form>
        </section>
    </main>
    <?php
        include "footer.html"
    ?>
    <script src="js/script.js"></script>
</body>
</html>