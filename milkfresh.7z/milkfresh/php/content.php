<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../css/content.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Главная</title>
</head>
<body>
    <?php
        include "header.html"
    ?>
    <section id="conteiner_1">
        <h1>Молочная феерия</h1>
        <h2>"Свежая молочная продукция -<br>
            прямо с фермы к вашему столу!"</h2>
    </section>
    <section id="conteiner_2">
        <div class="image">
            
        </div>
        <div class="Text_1">
            <h1>Молоко с <br>
            любовью</h1>
            <p>
                Мы — команда молочных магов, которые превращают свежие ингредиенты в настоящие шедевры! Наша продукция — это не просто молоко, это волшебство, которое вы можете пить.
                <br>
                <br>
                Каждый глоток нашей продукции — это как объятие от любимой бабушки. Мы заботимся о качестве, как о собственном ребенке, и гарантируем, что вы получите только лучшее.
                <br>
                <br>
                Присоединяйтесь к нашему молочному безумию и откройте для себя мир, где молоко не просто напиток, а целая философия!
            </p>
        </div>
        <section class="conteiner_2_2">
            <div class="image_3">
                
            </div>
            <div class="image_2">
                
            </div>
        </section>
    </section>
    <section id="conteiner_3">
        <h1>Наши партнёры</h1>
        <div class="image_4">

        </div>
        <div class="image_5"> 

        </div>
        <div class="image_6">

        </div>
    </section>
    <section id="conteiner_4">
        <h1>Популярные шедевры</h1>
        <div class="product-card">
            <img src="image_main_content/product-36-copyright.jpg" alt="">
            <p style="width: fit-content; height: auto; border: 1px solid black; margin: 0 auto; font-size: 20px;">
                Молоко
            </p>
            <h3>
                тростниииик
            </h3>
        </div>
        <div class="product-card">
            <img src="image_main_content/product-36-copyright.jpg" alt="">
            <p style="width: fit-content; height: auto; border: 1px solid black; margin: 0 auto; font-size: 20px;">
                Молоко
            </p>
            <h3>
                тростниииик
            </h3>
        </div>
        <div class="product-card">
            <img src="image_main_content/product-36-copyright.jpg" alt="">
            <p style="width: fit-content; height: auto; border: 1px solid black; margin: 0 auto; font-size: 20px;">
                Молоко
            </p>
            <h3>
                тростниииик
            </h3>
        </div>
        <div class="product-card">
            <img src="image_main_content/product-36-copyright.jpg" alt="">
            <p style="width: fit-content; height: auto; border: 1px solid black; margin: 0 auto; font-size: 20px;">
                Молоко
            </p>
            <h3>
                тростниииик
            </h3>
        </div>
        <div class="product-card">
            <img src="image_main_content/product-36-copyright.jpg" alt="">
            <p style="width: fit-content; height: auto; border: 1px solid black; margin: 0 auto; font-size: 20px;">
                Молоко
            </p>
            <h3>
                тростниииик
            </h3>
        </div>
        <div class="product-card">
            <img src="image_main_content/product-36-copyright.jpg" alt="">
            <p style="width: fit-content; height: auto; border: 1px solid black; margin: 0 auto; font-size: 20px;">
                Молоко
            </p>
            <h3>
                тростниииик
            </h3>
        </div>
        <div class="product-card">
            <img src="image_main_content/product-36-copyright.jpg" alt="">
            <p style="width: fit-content; height: auto; border: 1px solid black; margin: 0 auto; font-size: 20px;">
                Молоко
            </p>
            <h3>
                тростниииик
            </h3>
        </div>
        <div class="product-card">
            <img src="image_main_content/product-36-copyright.jpg" alt="">
            <p style="width: fit-content; height: auto; border: 1px solid black; margin: 0 auto; font-size: 20px;">
                Молоко
            </p>
            <h3>
                тростниииик
            </h3>
        </div>
    </section>
    <section id="conteiner_5">
        <h1>Команда главных творцов</h1>
        <div class="employee_card">
            <div class="image_7">
                
            </div>
            <p style="color: rgb(172, 172, 172);"><i>Ики</i></p>
            <h2>Молочный маг</h2>

        </div>
        <div class="employee_card">
            <div class="image_8">

            </div>
            <p style="color: rgb(172, 172, 172);"><i>Алексей</i></p>
            <h2>Творожный гуру</h2>
        </div>
        <div class="employee_card">
            <div class="image_9">

            </div>
            <p style="color: rgb(172, 172, 172);"><i>Светлана</i></p>
            <h2>Йогуртовый мастер</h2>
        </div>
        <div class="employee_card">
            <div class="image_10">

            </div>
            <p style="color: rgb(172, 172, 172);"><i>Сергей</i></p>
            <h2>Сырный волшебник</h2>
        </div>
        <hr width="60%" size="6" color="Lime" style="margin: 3% auto;">
        <div class="info">
            <h2>100%</h2>
            <h3>Натуральные продукты</h3>
        </div>
        <div class="info">
            <h2>24/7</h2>
            <h3>Доступность всегда</h3>
        </div>
        <div class="info">
            <h2>5</h2>
            <h3>Вкусных сортов</h3>
        </div>
        <div class="info">
            <h2>5</h2>
            <h3>Лет на онлайн рынке</h3>
        </div>
    </section>
    <section id="conteiner_6">
        <div class="content_2">
            <div class="image_11">

            </div>
            <hr width="65%" size="6" color="gainsboro" style="margin: 3% auto;">
            <h2 style="margin-top: 5%; text-align: center;">г. Иркутск, Партизанская ул., 63, 1, 2</h2>
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2441.1199011117697!2d104.30385297643444!3d52.27752517199859!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x5da83b4218ec28e9%3A0x24953c5051a96b85!2z0J_QsNGA0YLQuNC30LDQvdGB0LrQsNGPINGD0LsuLCA2MywgMSwgMiwg0JjRgNC60YPRgtGB0LosINCY0YDQutGD0YLRgdC60LDRjyDQvtCx0LsuLCA2NjQwNDc!5e0!3m2!1sru!2sru!4v1738574472229!5m2!1sru!2sru" width="100%" height="39%" style="border:0; border-radius: 10px;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
    </section>
    
</body>
</html>