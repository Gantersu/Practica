<?php
session_start();

// Уничтожаем все данные сессии
session_unset();
session_destroy();

// Перенаправляем на страницу авторизации
header("Location: ../no auto/content.php"); // Замените index.html на имя вашего файла формы
exit();
?>