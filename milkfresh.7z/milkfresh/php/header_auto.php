<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MilkFresh</title>
    <link rel="stylesheet" href="../css/header.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <a href="#" class="logo">MilkFresh</a>
            <nav class="menu">
                <ul>
                    <li><a href="#">Главная</a></li>
                    <li><a href="#">О нас</a></li>
                    <li><a href="#">Контакты</a></li>
                    <li><a href="#">Продукция</a></li>
                    <h4>Добро пожаловать!</h4>
                    <a href="logout.php">Выйти</a>
                </ul>
            </nav>
        </div>
    </header>
</body>
</html>
