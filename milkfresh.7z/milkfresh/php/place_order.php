<?php
session_start();
require_once 'config.php';

$address = $_POST['address'];
$phone = $_POST['phone'];
$payment = $_POST['payment'];

// Валидация входных данных
if (empty($address) || empty($phone) || empty($payment)) {
    echo json_encode(array('status' => 'error', 'message' => 'Please fill all fields'));
    exit;
}

//  Получаем товары из корзины
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    echo json_encode(array('status' => 'error', 'message' => 'Cart is empty'));
    exit;
}

$cart_items = $_SESSION['cart'];
$total_amount = 0;

//  Рассчитываем общую сумму заказа (еще раз для надежности)
foreach ($cart_items as $item) {
    $total_amount += $item['price'];
}

//  Начинаем транзакцию (для обеспечения целостности данных)
$conn->begin_transaction();

try {
    // 1.  Создаем запись о заказе в таблице `orders`
    $sql_order = "INSERT INTO orders (customer_phone, shipping_address, payment_method, total_amount)
                  VALUES ('" . $phone . "', '" . $address . "', '" . $payment . "', " . $total_amount . ")";

    if ($conn->query($sql_order) === FALSE) {
        throw new Exception("Error creating order: " . $conn->error);
    }

    $order_id = $conn->insert_id; // Получаем ID созданного заказа

    // 2.  Добавляем записи о товарах в заказе в таблицу `order_items`
    foreach ($cart_items as $item) {
        $product_id = $item['product_id'];
        $quantity = $item['quantity'];
        $price = $item['price'] / $quantity;  // Цена за единицу товара

        $sql_order_item = "INSERT INTO order_items (order_id, product_id, quantity, price)
                           VALUES (" . $order_id . ", " . $product_id . ", " . $quantity . ", " . $price . ")";

        if ($conn->query($sql_order_item) === FALSE) {
            throw new Exception("Error creating order item: " . $conn->error);
        }
    }

    //  Если все успешно, подтверждаем транзакцию
    $conn->commit();

    //  Очищаем корзину
    unset($_SESSION['cart']);

    echo json_encode(array('status' => 'success'));

} catch (Exception $e) {
    //  Если произошла ошибка, откатываем транзакцию
    $conn->rollback();
    echo json_encode(array('status' => 'error', 'message' => $e->getMessage()));
}

$conn->close();
?>