<?php
session_start(); //  Начинаем сессию (если используем сессии для хранения корзины)
require_once 'config.php';

$product_id = $_POST['product_id'];
$quantity = $_POST['quantity'];

// Валидация входных данных (ОЧЕНЬ ВАЖНО!)
if (!is_numeric($product_id) || !is_numeric($quantity) || $quantity < 1) {
    echo json_encode(array('status' => 'error', 'message' => 'Invalid data'));
    exit;
}

//  Пример: хранение в сессии
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
}

//  Проверка, есть ли уже товар в корзине
$found = false;
foreach ($_SESSION['cart'] as &$item) { // &$item - передача по ссылке для изменения
    if ($item['product_id'] == $product_id) {
        $item['quantity'] += $quantity;
        $found = true;
        break;
    }
}

if (!$found) {
    //  Получаем информацию о товаре из БД (цену, название)
    $sql = "SELECT id, name, price FROM products WHERE id = " . $product_id;
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        $_SESSION['cart'][] = array(
            'product_id' => $product_id,
            'name' => $row['name'],
            'quantity' => $quantity,
            'price' => $row['price'] * $quantity //  Вычисляем цену сразу
        );
    } else {
        echo json_encode(array('status' => 'error', 'message' => 'Product not found'));
        exit;
    }
}
unset($item); //  Удаляем ссылку &$item

echo json_encode(array('status' => 'success'));
$conn->close();
?>