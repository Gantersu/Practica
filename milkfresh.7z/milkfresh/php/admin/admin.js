//  Здесь может быть JavaScript для добавления функциональности
//  Например, загрузка контента для edit_product.php, delete_product.php, order_history.php  в <main> через AJAX