<?php
require_once '../config.php';

// Запрос на выборку всех заказов
$sql = "SELECT * FROM orders ORDER BY order_date DESC";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html>
<head>
    <title>История заказов</title>
    <link rel="stylesheet" href="admin.css">
</head>
<body>
    <h1>История заказов</h1>
    <a href="../../admin.html">Вернуться на главную</a><br><br>
    <table>
        <thead>
            <tr>
                <th>ID заказа</th>
                <th>Телефон клиента</th>
                <th>Адрес доставки</th>
                <th>Метод оплаты</th>
                <th>Сумма заказа</th>
                <th>Дата заказа</th>
                <th>Статус</th>
                <th>Действие</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["id"] . "</td>";
                    echo "<td>" . $row["customer_phone"] . "</td>";
                    echo "<td>" . $row["shipping_address"] . "</td>";
                    echo "<td>" . $row["payment_method"] . "</td>";
                    echo "<td>" . $row["total_amount"] . "</td>";
                    echo "<td>" . $row["order_date"] . "</td>";
                    echo "<td>" . $row["order_status"] . "</td>";
                    echo "<td><a href='view_order.php?id=" . $row["id"] . "'>Просмотреть</a> | <a href='update_order_status.php?id=" . $row["id"] . "'>Обновить статус</a></td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='8'>No orders found.</td></tr>";
            }
            ?>
        </tbody>
    </table>

    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>

</body>
</html>