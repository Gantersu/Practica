<?php
require_once '../config.php';

// Проверяем, был ли передан ID заказа
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $order_id = $_GET['id'];

    //  Обработка отправки формы обновления статуса
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $new_status = $_POST['order_status'];

        $sql = "UPDATE orders SET order_status = '$new_status' WHERE id = " . $order_id;

        if ($conn->query($sql) === TRUE) {
            echo "Order status updated successfully.";
            header("Location: order_history.php"); // Перенаправление обратно к истории заказов
            exit;
        } else {
            echo "Error updating order status: " . $conn->error;
        }
    }

    //  Получаем текущий статус заказа для отображения в форме
    $sql_get_status = "SELECT order_status FROM orders WHERE id = " . $order_id;
    $result_get_status = $conn->query($sql_get_status);

    if ($result_get_status->num_rows == 1) {
        $row = $result_get_status->fetch_assoc();
        $current_status = $row['order_status'];
    } else {
        echo "Order not found.";
        exit;
    }

?>

<!DOCTYPE html>
<html>
<head>
    <title>Обновить статус заказа</title>
    <link rel="stylesheet" href="admin.css">
</head>
<body>
    <h1>Обновить статус заказа</h1>

    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"] . "?id=" . $order_id); ?>">
        <label for="order_status">Новый статус:</label>
        <select id="order_status" name="order_status">
            <option value="Ожидаемый" <?php if ($current_status == 'Ожидаемый') echo 'selected'; ?>>Ожидаемый</option>
            <option value="Отправленный" <?php if ($current_status == 'Отправленный') echo 'selected'; ?>>Отправленный</option>
            <option value="Завершённый" <?php if ($current_status == 'Завершённый') echo 'selected'; ?>>Завершённый</option>
            <option value="Отменённый" <?php if ($current_status == 'Отменённый') echo 'selected'; ?>>Отменённый</option>
        </select><br><br>

        <input type="submit" value="Обновить статус">
    </form>

</body>
</html>

<?php
} else {
    echo "Invalid order ID.";
}
?>