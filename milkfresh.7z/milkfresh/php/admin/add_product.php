<?php
require_once '../config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $category = $_POST['category'];
    $description = $_POST['description'];
    $image = $_POST['image'];
    $price = $_POST['price'];
    $quantity = $_POST['quantity'];

    $sql = "INSERT INTO products (name, category, description, image, price, quantity)
            VALUES ('$name', '$category', '$description', '$image', $price, $quantity)";

    if ($conn->query($sql) === TRUE) {
        echo "Product added successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Добавить товар</title>
    <link rel="stylesheet" href="admin.css">
</head>
<body>
    <h1>Добавление нового товара</h1>

    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <label for="name">Имя:</label>
        <input type="text" id="name" name="name" required><br><br>

        <label for="category">Категория:</label>
        <select id="category" name="category" required>
            <option value="Молоко">Молоко</option>
            <option value="Творог">Творог</option>
            <option value="Йогурт">Йогурт</option>
            <option value="Сыр">Сыр</option>
        </select><br><br>

        <label for="description">Описание:</label>
        <textarea id="description" name="description" required></textarea><br><br>

        <label for="image">URL-адрес изображения:</label>
        <input type="text" id="image" name="image" required><br><br>

        <label for="price">Цена:</label>
        <input type="number" id="price" name="price" step="0.01" required><br><br>

        <label for="quantity">Количество:</label>
        <input type="number" id="quantity" name="quantity" required><br><br>

        <input type="submit" value="Добавить">
    </form>
</body>
</html>