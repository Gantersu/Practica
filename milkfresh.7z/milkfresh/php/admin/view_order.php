<?php
require_once '../config.php';

// Проверяем, был ли передан ID заказа
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $order_id = $_GET['id'];

    // Получаем информацию о заказе
    $sql_order = "SELECT * FROM orders WHERE id = " . $order_id;
    $result_order = $conn->query($sql_order);

    if ($result_order->num_rows == 1) {
        $order = $result_order->fetch_assoc();

        // Получаем товары в заказе
        $sql_items = "SELECT oi.quantity, oi.price, p.name FROM order_items oi
                      JOIN products p ON oi.product_id = p.id
                      WHERE oi.order_id = " . $order_id;
        $result_items = $conn->query($sql_items);

        $order_items = array();
        while ($row = $result_items->fetch_assoc()) {
            $order_items[] = $row;
        }

    } else {
        echo "Order not found.";
        exit;
    }
} else {
    echo "Invalid order ID.";
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Order</title>
    <link rel="stylesheet" href="admin.css">
</head>
<body>
    <h1>Просмотр заказа</h1>

    <h2>Детали заказа</h2>
    <p>ID заказа: <?php echo $order['id']; ?></p>
    <p>Телефон клиента: <?php echo $order['customer_phone']; ?></p>
    <p>Адрес доставки: <?php echo $order['shipping_address']; ?></p>
    <p>Метод оплаты: <?php echo $order['payment_method']; ?></p>
    <p>Общая сумма: <?php echo $order['total_amount']; ?></p>
    <p>Дата заказа: <?php echo $order['order_date']; ?></p>
    <p>Статус заказ: <?php echo $order['order_status']; ?></p>

    <h2>Детали заказа</h2>
    <table>
        <thead>
            <tr>
                <th>Название товара</th>
                <th>Количество</th>
                <th>Цена</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($order_items as $item): ?>
                <tr>
                    <td><?php echo $item['name']; ?></td>
                    <td><?php echo $item['quantity']; ?></td>
                    <td><?php echo $item['price']; ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

</body>
</html>