<?php
require_once '../config.php';

// Проверяем, был ли передан ID продукта для удаления
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $product_id = $_GET['id'];

    // Удаляем продукт из базы данных
    $sql = "DELETE FROM products WHERE id = " . $product_id;

    if ($conn->query($sql) === TRUE) {
        echo "Товар успешно удалён.";
    } else {
        echo "Ошибка удаления товара: " . $conn->error;
    }
} else {
    echo "Неверный идентификатор товара.";
}

?>
<br>
    <a href="../../admin.html">Вернуться на главную</a><br><br>