<?php
require_once '../config.php';


//  Обработка обновления продукта
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id'])) {  // Проверяем, что передан product_id
    $product_id = $_POST['id']; //  Получаем product_id из POST
    $name = $_POST['name'];
    $category = $_POST['category'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $quantity = $_POST['quantity'];
    $imageFileName = $_POST['image'];

    $sql = "UPDATE products SET
                name = '$name',
                category = '$category',
                description = '$description',
                image = '$imageFileName',
                price = $price,
                quantity = $quantity
            WHERE id = " . $product_id;

    if ($conn->query($sql) === TRUE) {
        echo "<p style='color: green;'>Товар успешно редактирован.</p>";
    } else {
        echo "<p style='color: red;'>Ошибка редактирования товара: " . $conn->error . "</p>";
    }
}

// Получаем список продуктов для редактирования
$sql = "SELECT id, name, category, description, image, price, quantity FROM products";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html>
<head>
    <title>Редактирование</title>
    <link rel="stylesheet" href="admin.css">
    <style>
    .product-list {
        display: flex;
        flex-wrap: wrap;
    }

    .product-item {
        width: 300px; /*  Ширина карточки товара  */
        margin: 10px;
        padding: 10px;
        border: 1px solid #ddd;
    }

    .product-item img {
        max-width: 100%;
        height: auto;
    }
    </style>
</head>
<body>
    <h1>Редактировать товар</h1>
    <a href="../../admin.html">Вернуться на главную</a><br><br>
    <h2>Лист товаров</h2>
    <div class="product-list">
    <?php
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo "<div class='product-item'>";
            echo "<img src='" . $row["image"] . "' alt='" . $row["name"] . "'>";
            echo "<h3>" . $row["name"] . "</h3>";
            echo "<p>Категория: " . $row["category"] . "</p>";
            echo "<p>Цена: " . $row["price"] . "</p>";
            echo "<a href='?edit_id=" . $row["id"] . "'>Редактировать</a> | ";
            echo "<a href='delete_product.php' class='delete-product-btn' data-id='" . $row["id"] . "'>Удалить</a>"; // Используем кнопку с data-id
            echo "</div>";
        }
    } else {
        echo "Товар не найден.";
    }
    ?>
    </div>

    <h2><?php echo isset($_GET['edit_id']) ? 'Редактировать товар' : 'Добавить новый товар'; ?></h2>

    <?php
    if (isset($_GET['edit_id']) && is_numeric($_GET['edit_id'])) {
        $edit_id = $_GET['edit_id'];
        $sql_edit = "SELECT id, name, category, description, image, price, quantity FROM products WHERE id = " . $edit_id;
        $result_edit = $conn->query($sql_edit);
        if ($result_edit->num_rows == 1) {
            $product = $result_edit->fetch_assoc();
            ?>

            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">  <!-- Скрытое поле для ID продукта -->
                <label for="name">Название:</label>
                <input type="text" id="name" name="name" value="<?php echo $product['name']; ?>" required><br><br>

                <label for="category">Категория:</label>
                <img src="" alt="<?php echo htmlspecialchars($product['name']); ?>" width="100"><br><br>
                <select id="category" name="category" required>
                    <option value="Молоко" <?php if ($product['category'] == 'Молоко') echo 'selected'; ?>>Молоко</option>
                    <option value="Творог" <?php if ($product['category'] == 'Творог') echo 'selected'; ?>>Творог</option>
                    <option value="Йогурт" <?php if ($product['category'] == 'Йогурт') echo 'selected'; ?>>Йогурт</option>
                    <option value="Сыр" <?php if ($product['category'] == 'Сыр') echo 'selected'; ?>>Сыр</option>
                </select><br><br>

                <label for="description">Описание:</label>
                <textarea id="description" name="description" required><?php echo htmlspecialchars($product['description']); ?></textarea><br><br>

                <label for="image">Изображение:</label>
                <select id="image" name="image" required>
                    <?php
                    //  Получаем список файлов изображений из папки
                    $imageDir = '../../images/'; //  Путь к папке с изображениями
                    $images = glob($imageDir . '*.{jpg,jpeg,png,gif}', GLOB_BRACE);

                    //  Выводим опции выпадающего списка
                    if (!empty($images)) {
                        foreach ($images as $image) {
                            $fileName = basename($image); //  Получаем только имя файла
                            echo "<option value='" . htmlspecialchars($fileName) . "'>" . htmlspecialchars($fileName) . "</option>";
                        }
                    } else {
                        echo "<option value=''>ИЗображение не найдено</option>";
                    }
                    ?>
                </select><br><br>

                <label for="price">Цена:</label>
                <input type="number" id="price" name="price" step="0.01" value="<?php echo $product['price']; ?>" required><br><br>

                <label for="quantity">Количество:</label>
                <input type="number" id="quantity" name="quantity" value="<?php echo $product['quantity']; ?>" required><br><br>

                <input type="submit" value="Обновить">
            </form>

            <?php
        } else {
            echo "<p style='color: red;'>Товар не найден.</p>";
        }
    }  else {
         //  Форма для добавления нового товара (если edit_id не передан)
         ?>
            <form method="post" action="add_product.php">
                <label for="name">Название:</label>
                <input type="text" id="name" name="name" required><br><br>

                <label for="category">Категория:</label>
                <select id="category" name="category" required>
                    <option value="Молоко">Молоко</option>
                    <option value="Творог">Творог</option>
                    <option value="Йогурт">Йогурт</option>
                    <option value="Сыр">Сыр</option>
                </select><br><br>

                <label for="description">Описание:</label>
                <textarea id="description" name="description" required></textarea><br><br>

                <label for="image">Изображение:</label>
                <select id="image" name="image" required>
                    <?php
                    //  Получаем список файлов изображений из папки
                    $imageDir = '../../images/'; //  Путь к папке с изображениями
                    $images = glob($imageDir . '*.{jpg,jpeg,png,gif}', GLOB_BRACE);

                    //  Выводим опции выпадающего списка
                    if (!empty($images)) {
                        foreach ($images as $image) {
                            $fileName = basename($image); //  Получаем только имя файла
                            echo "<option value='" . htmlspecialchars($fileName) . "'>" . htmlspecialchars($fileName) . "</option>";
                        }
                    } else {
                        echo "<option value=''>ИЗображение не найдено</option>";
                    }
                    ?>
                </select><br><br>

                <label for="price">Цена:</label>
                <input type="number" id="price" name="price" step="0.01" required><br><br>

                <label for="quantity">Количество:</label>
                <input type="number" id="quantity" name="quantity" required><br><br>

                <input type="submit" value="Добавить товар">
            </form>
         <?php

    }
    ?>
</body>
</html>
<?php $conn->close(); ?>