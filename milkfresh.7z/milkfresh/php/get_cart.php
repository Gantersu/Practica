<?php
session_start(); //  Начинаем сессию
header('Content-Type: application/json');

if (isset($_SESSION['cart'])) {
    echo json_encode($_SESSION['cart']);
} else {
    echo json_encode(array()); // Возвращаем пустой массив, если корзина пуста
}
?>