<?php
session_start();
require_once 'config.php';

$product_id = $_POST['product_id'];

// Валидация входных данных
if (!is_numeric($product_id)) {
    echo json_encode(array('status' => 'error', 'message' => 'Invalid product ID'));
    exit;
}

if (isset($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $key => $item) {
        if ($item['product_id'] == $product_id) {
            unset($_SESSION['cart'][$key]); // Удаляем элемент из массива
            $_SESSION['cart'] = array_values($_SESSION['cart']); // Переиндексируем массив
            echo json_encode(array('status' => 'success'));
            exit;
        }
    }
}

echo json_encode(array('status' => 'error', 'message' => 'Product not found in cart'));
?>