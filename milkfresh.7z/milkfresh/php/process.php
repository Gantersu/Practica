<?php
session_start();
require_once 'config.php';

// Обработка регистрации
if (isset($_POST['register'])) {
    $name = $_POST['txt'];
    $email = $_POST['email'];
    $password = $_POST['pswd'];

    // *** ВАЖНО: Хешируйте пароль перед сохранением в базу данных! ***
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // *** Используйте подготовленные запросы для защиты от SQL-инъекций! ***
    $sql = "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $role = "user"; // Устанавливаем значение по умолчанию
    $stmt->bind_param("ssss", $name, $email, $hashed_password, $role);

    if ($stmt->execute()) {
        $_SESSION['success_message'] = "Регистрация прошла успешно! Войдите в систему.";
        header("Location: ../form.html"); // Перенаправление на форму входа
        exit();
    } else {
        $_SESSION['error_message'] = "Ошибка регистрации: " . $stmt->error;
        header("Location: ../form.html"); // Перенаправление на форму регистрации
        exit();
    }
    $stmt->close();
}

// Обработка авторизации
if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['pswd'];

    // *** Используйте подготовленные запросы для защиты от SQL-инъекций! ***
    $sql = "SELECT id, password, role FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();

        // *** ВАЖНО: Используйте password_verify для проверки пароля! ***
        if (password_verify($password, $user['password'])) {
            // Проверка роли пользователя
            if ($user['role'] == "admin") {
                $_SESSION['admin_logged_in'] = true;
                $_SESSION['user_id'] = $user['id']; // Сохраняем ID пользователя
                header("Location: ../admin.html"); // Перенаправление в админ-панель
                exit();
            } else {
                // Обычный пользователь
                $_SESSION['user_id'] = $user['id'];
                header("Location: ../auto/content.php"); // Перенаправление на главную страницу пользователя
                exit();
            }
        } else {
            // Неверный пароль $2y$10$HW1.Sg7SOBvFy0KJx4SCjuN5WohWCwbo94F56kcw3ni3wBBB9iDgW 
            $_SESSION['login_error'] = "Неверный email или пароль.";
            header("Location: ../form.html");  // Вернуться на форму авторизации
            exit();
        }
    } else {
        // Пользователь не найден
        $_SESSION['login_error'] = "Неверный email или пароль.";
        header("Location: ../form.html"); // Вернуться на форму авторизации
        exit();
    }
    $stmt->close();
}

$conn->close();
?>