document.addEventListener('DOMContentLoaded', function() {
    // 1. Загрузка товаров из БД
    loadProducts();

    // 2.  Обработчик события добавления в корзину (делегирование)
    document.addEventListener('click', function(event) {
        if (event.target.classList.contains('add-to-cart-btn')) {
            const productId = event.target.dataset.productId;
            const quantity = parseInt(event.target.closest('.product-card').querySelector('.quantity-select').value);
            addToCart(productId, quantity);
        }
    });

    // 3.  Обработчик события изменения количества (делегирование)
    document.addEventListener('change', function(event) {
        if (event.target.classList.contains('quantity-select')) {
            const productId = event.target.dataset.productId;
            const quantity = parseInt(event.target.value);
            updateProductPrice(productId, quantity, event.target.closest('.product-card')); // Обновляем цену в карточке
        }
    });

    // 4. Обработчик отправки формы заказа
    const orderForm = document.getElementById('order-form');
    if (orderForm) {
        orderForm.addEventListener('submit', function(event) {
            event.preventDefault();
            placeOrder();
        });
    }

    // 5. Загрузка корзины при загрузке страницы
    loadCart();

    // Функция для загрузки товаров из PHP
    function loadProducts() {
        fetch('php/get_products.php')
            .then(response => response.json())
            .then(data => {
                data.forEach(product => {
                    addProductToCategory(product);
                });
            })
            .catch(error => console.error('Ошибка загрузки товаров:', error));
    }

    // Функция для добавления товара в категорию
    function addProductToCategory(product) {
        const categoryDiv = document.querySelector(`.category[data-category="${product.category}"] .product-container`);
        if (!categoryDiv) return;

        const productCard = document.createElement('div');
        productCard.classList.add('product-card');
        productCard.innerHTML = `
            <img src="images/" alt="${product.name}">  // Измените путь
            <h3>${product.name}</h3>
            <p>${product.description}</p>
            <p>Цена: <span class="product-price">${product.price}</span> руб.</p>
            <label for="quantity">Количество:</label>
            <select class="quantity-select" data-product-id="${product.id}">
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
            </select>
            <button class="add-to-cart-btn" data-product-id="${product.id}">Добавить в корзину</button>
        `;
        categoryDiv.appendChild(productCard);

        //  Инициализация цены при загрузке
        updateProductPrice(product.id, 1, productCard);
    }

    // Функция обновления цены товара при изменении количества
    function updateProductPrice(productId, quantity, productCard) {
        //  Найдем карточку товара по productId, если она не была передана
        if (!productCard) {
            productCard = document.querySelector(`.product-card .add-to-cart-btn[data-product-id="${productId}"]`).closest('.product-card');
        }
        if (!productCard) return;

        // Получаем цену из HTML
        let price = parseFloat(productCard.querySelector('.product-price').textContent);
        let totalPrice = price * quantity;
        productCard.querySelector('.product-price').textContent = totalPrice.toFixed(2); // Обновляем цену в карточке
    }

    // Функция добавления товара в корзину (отправка на сервер)
    function addToCart(productId, quantity) {
        fetch('php/add_to_cart.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `product_id=${productId}&quantity=${quantity}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                loadCart(); // Обновляем корзину
                alert('Товар добавлен в корзину!');
            } else {
                alert('Ошибка добавления товара в корзину.');
            }
        })
        .catch(error => console.error('Ошибка:', error));
    }

    // Функция для загрузки корзины из сессии/куки (отправка на сервер)
    function loadCart() {
        fetch('php/get_cart.php')
            .then(response => response.json())
            .then(data => {
                displayCart(data);
            })
            .catch(error => console.error('Ошибка загрузки корзины:', error));
    }

    // Функция отображения товаров в корзине
    function displayCart(cartItems) {
        const cartItemsDiv = document.getElementById('cart-items');
        const totalPriceSpan = document.getElementById('total-price');

        cartItemsDiv.innerHTML = ''; // Очищаем корзину

        let totalPrice = 0;

        cartItems.forEach(item => {
            const cartItemDiv = document.createElement('div');
            cartItemDiv.classList.add('cart-item');
            cartItemDiv.innerHTML = `
                <span>${item.name} x ${item.quantity}</span>
                <span>${item.price} руб.</span>
                <button class="remove-from-cart-btn" data-product-id="${item.product_id}">Удалить</button>
            `;
            cartItemsDiv.appendChild(cartItemDiv);
            totalPrice += item.price;
        });

        totalPriceSpan.textContent = totalPrice.toFixed(2);
    }

    // Функция удаления товара из корзины (отправка на сервер)
    document.addEventListener('click', function(event) {
        if (event.target.classList.contains('remove-from-cart-btn')) {
            const productId = event.target.dataset.productId;
            removeFromCart(productId);
        }
    });

    function removeFromCart(productId) {
        fetch('php/remove_from_cart.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `product_id=${productId}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                loadCart(); // Обновляем корзину
                alert('Товар удален из корзины!');
            } else {
                alert('Ошибка удаления товара из корзины.');
            }
        })
        .catch(error => console.error('Ошибка:', error));
    }

    // Функция оформления заказа (отправка на сервер)
    function placeOrder() {
        const address = document.getElementById('address').value;
        const phone = document.getElementById('phone').value;
        const payment = document.getElementById('payment').value;

        fetch('php/place_order.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `address=${address}&phone=${phone}&payment=${payment}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                alert('Заказ успешно оформлен!');
                //  Перенаправление на страницу благодарности
                window.location.href = 'thank_you.html';
            } else {
                alert('Ошибка оформления заказа.');
            }
        })
        .catch(error => console.error('Ошибка:', error));
    }

});